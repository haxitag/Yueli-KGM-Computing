# Yueli KGM Computing

`@haxitag/yueli-kgm-computing` — 阅粒 **KGM**（Knowledge Graph & Model runtime）：自托管的 **OpenAI / Anthropic 兼容网关与编排层**，内建 **进程内 Native 推理** 与 **受管模型控制面**；支持 `kgm` 扩展（工具、图谱信号、检索、观测等）。

- **环境**：Node **20.x**（与 `package.json` 的 `engines` 一致）
- **官方文档**（能力说明、部署、API、Playground 等）：[阅粒知识计算引擎 — HaxiTAG](https://www.haxitag.com/read/yueli-knowledge-computation-engine-system)
- **使用指南**（企业场景、落地与 Q&A 等）：[Yueli KGM Engine 使用指南](https://www.haxitag.com/articles/yueli-kgm-engine-enterprise-ai-qa-solution)
- **npm 包内容**：`dist/`（运行时代码）+ `playground/`（Web Playground 静态资源）+ 本 `README`；**不**再内置仓库中的大量 `docs/*.md`，以减小包体；完整文档以官网为准
- **生产加固（可选）**：`KGM_HTTP_API_KEY`（`Authorization: Bearer` 或 `X-API-Key`）；`KGM_HTTP_AUTH_EXEMPT` 逗号路径前缀，默认只豁免 `/health`（若开启 API Key 且需本机 Playground，可加入 `/api` 等前缀）；`KGM_HTTP_RATE_LIMIT_MAX` + `KGM_HTTP_RATE_LIMIT_WINDOW_MS`（`MAX=0` 表示不限流）
- **OpenAPI 3.1**：`GET /openapi.json`（主规范同 `src/openapi/kgmOpenApiV1Spec.ts`）
- **Runtime 观测层**：`GET /v1/runtime/status`、`/topology`、`/discovery`、`/diagnostics`，以及 `POST /v1/runtime/route/explain`，用于应用端启动体检、模型发现、路由预检与失败解释
- **检索三阶段**：`kgm.retrieval.strategy=hybrid`（BM25+向量）、`kgm.retrieval.rerank=embed`（双塔成对编码）或 `rerank=http` + `KGM_RERANK_HTTP_URL`
- **图与多模态**
  - 图：`POST /v1/kgm/graph/communities`、`reason/expand`、`reason/rules` 等
  - 多模态：`POST /v1/kgm/multimodal/embed`：KGM 将请求转发到由环境变量指定的上游图像向量服务
    - 必填：`KGM_MULTIMODAL_BASE_URL`
    - 常用：`KGM_MULTIMODAL_PATH`（默认 `"/v1/embeddings"`）、`KGM_MULTIMODAL_MODEL`（默认 `"clip"`）、`KGM_MULTIMODAL_KEY`、`KGM_MULTIMODAL_TIMEOUT_MS`（默认 `120000`）
    - `KGM_MULTIMODAL_JSON_TEMPLATE=1`：对上游发 `{ model, image, mime, text? }`；否则默认 `{ model, input: [dataUrl] }`

---

## Non-goals

KGM 主包聚焦统一推理入口、模型与引擎生命周期、动态路由、运行时可观测性。以下能力不由 KGM 主包持有：

- KGM 不管理应用层 session / 对话历史
- KGM 不执行应用业务 skill；只承载 OpenAI Compatible 的 `tools` / `tool_choice` 协议
- KGM 不做 multi-agent orchestration
- KGM 不持有应用端 UI 状态

Agent、Workflow、Evaluation、Skills registry 等高层能力建议以 plugin extension 形式挂载，避免主包承担应用编排职责。

---

## 快速开始（带 Playground）

```bash
mkdir kgm-host && cd kgm-host
npm init -y
npm install @haxitag/yueli-kgm-computing@latest

export PORT=3000
export KGM_LLM_BASE_URL="https://api.openai.com/v1"
export KGM_LLM_API_KEY="sk-..."
export KGM_LLM_MODEL="gpt-4o-mini"
export KGM_LLM_MODE="chat"
export KGM_LLM_PATH="/chat/completions"
export KGM_MOCK_MODE=0

node ./node_modules/@haxitag/yueli-kgm-computing/dist/server/enhancedStart.js
```

浏览器访问：`http://localhost:3000/`（Playground），`http://localhost:3000/metrics`（Prometheus 文本指标）。

**OpenAI 兼容**最小请求示例：

```bash
curl -sS "http://127.0.0.1:3000/v1/chat/completions" \
  -H "content-type: application/json" \
  -d '{
    "model": "auto",
    "messages": [
      { "role": "user", "content": "用一句话说明 KGM 是什么" }
    ]
  }'
```

---

## Runtime Layer 与应用端预检

应用端推荐启动时先调用：

```bash
curl -sS http://127.0.0.1:3000/v1/runtime/status
curl -sS http://127.0.0.1:3000/v1/runtime/discovery
curl -sS http://127.0.0.1:3000/v1/models/effective
```

发起推理前可用 `POST /v1/runtime/route/explain` 做 preflight。该接口不执行推理、不消耗 token，只返回 KGM 会选择的路径、候选模型、阻塞问题和 `wouldUseMock`。

`KGM_MOCK_MODE=1` 仅用于本地开发；所有受影响响应会带 `kgm.mock=true`，`/v1/runtime/status` 会返回 `mockMode=true`。生产环境应 unset 或设置 `KGM_MOCK_MODE=0`。

### KGM 核心环境变量

配置优先级为：`env > playground > discovery > config-file > default`。`/v1/runtime/status` 会在 `llm.source` / `embedding.source` 中暴露当前可识别来源。

```text
KGM_LLM_BASE_URL / KGM_LLM_API_KEY / KGM_LLM_MODEL / KGM_LLM_PATH / KGM_LLM_MODE / KGM_LLM_PROVIDER
KGM_EMBEDDING_BASE_URL / KGM_EMBEDDING_API_KEY / KGM_EMBEDDING_MODEL / KGM_EMBEDDING_PATH / KGM_EMBEDDING_PROVIDER
KGM_DISCOVERY_ENABLED / KGM_DISCOVERY_PORTS / KGM_DISCOVERY_TIMEOUT_MS
KGM_MOCK_MODE
KGM_HTTP_API_KEY / KGM_HTTP_RATE_LIMIT_MAX / KGM_HTTP_RATE_LIMIT_WINDOW_MS
KGM_CONFIG_PATH / KGM_DB_PATH / KGM_VECTOR_BACKEND
```

自动发现本机 OpenAI-compatible 引擎示例：

```bash
export KGM_DISCOVERY_ENABLED=1
export KGM_DISCOVERY_PORTS="11434 8002 8080 1234 8000 5000"
export KGM_DISCOVERY_TIMEOUT_MS=2000
```

---

## 两种集成方式

### A. 独立服务（HTTP，适合多语言 / 多微服务）

在别处部署 KGM 进程，业务侧只调 HTTP：`/v1/chat/completions`、`/v1/responses`、`/v1/messages`，以及管理面 `/v1/kgm/*` 等。入口脚本可选：

- `dist/server/enhancedStart.js`：含 **Playground** 与相关路由
- `dist/server/start.js`：偏 **纯 API**（无内置 Playground 静态页）

### B. 进程内集成（Node，适合单体或自建网关）

```js
import { createRuntime, createKgmServer } from "@haxitag/yueli-kgm-computing";

const runtime = createRuntime({});
const server = createKgmServer({
  scheduler: runtime.scheduler,
  contextBuilder: runtime.contextBuilder,
  llmClient: runtime.llmClient,
  schemaRegistry: runtime.schemaRegistry,
  toolRegistry: runtime.toolRegistry,
  memoryStore: runtime.memoryStore,
  graphStore: runtime.graphStore,
  embedder: runtime.embedder,
  sandboxManager: runtime.sandboxManager,
  modelManager: runtime.modelManager,
  autoRoutingClient: runtime.autoRoutingClient,
  configStore: runtime.configStore,
  skillRuntime: runtime.skillRuntime,
  artifactStore: runtime.artifactStore,
  sessionStore: runtime.sessionStore
});

server.listen(process.env.PORT || 3000);
```

更细的实战步骤与排错仍以官网文档为准。

---

## 跨语言集成指南

KGM 作为 NPM 包，可与 Rust、Golang、Python、Node.js 等技术栈灵活集成。以下是常见集成方案：

### Node.js 直接集成（推荐）

```typescript
import { createRuntime, createKgmServer } from "@haxitag/yueli-kgm-computing";

// 初始化运行时
const runtime = createRuntime({
  llm: {
    baseURL: process.env.KGM_LLM_BASE_URL,
    apiKey: process.env.KGM_LLM_API_KEY,
    model: process.env.KGM_LLM_MODEL,
  },
});

// 创建服务
const server = createKgmServer({
  scheduler: runtime.scheduler,
  contextBuilder: runtime.contextBuilder,
  llmClient: runtime.llmClient,
  toolRegistry: runtime.toolRegistry,
  memoryStore: runtime.memoryStore,
  graphStore: runtime.graphStore,
  embedder: runtime.embedder,
});

server.listen(3000);
```

### Rust 集成（子进程 + STDIO）

适用于需要高性能推理引擎的场景：

```rust
// rust_engine/src/main.rs
use serde::{Deserialize, Serialize};
use std::process::{Command, Stdio};
use std::io::{BufRead, BufReader, Write};

#[derive(Serialize)]
struct InferenceRequest {
    model: String,
    prompt: String,
    max_tokens: u32,
}

#[derive(Deserialize)]
struct InferenceResponse {
    content: String,
    tokens: u32,
}

fn inference(request: InferenceRequest) -> Result<InferenceResponse, Box<dyn std::error::Error>> {
    let mut child = Command::new("./target/release/shimmy")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .spawn()?;

    let mut stdin = child.stdin.take().unwrap();
    stdin.write_all(serde_json::to_string(&request)?.as_bytes())?;
    drop(stdin);

    let reader = BufReader::new(child.stdout.take().unwrap());
    let response: InferenceResponse = serde_json::from_reader(reader)?;
    Ok(response)
}
```

```typescript
// src/integrations/rustEngine.ts
import { spawn, ChildProcess } from 'child_process';

export class RustEngineClient {
  private process: ChildProcess;

  constructor(binaryPath: string) {
    this.process = spawn(binaryPath, [], {
      stdio: ['pipe', 'pipe', 'inherit'],
    });
  }

  async inference(request: {
    model: string;
    prompt: string;
    max_tokens: number;
  }): Promise<{ content: string; tokens: number }> {
    return new Promise((resolve, reject) => {
      const data = JSON.stringify(request) + '\n';
      this.process.stdin?.write(data);

      let buffer = '';
      const handler = (chunk: Buffer) => {
        buffer += chunk.toString();
        try {
          const response = JSON.parse(buffer);
          this.process.stdout?.removeListener('data', handler);
          resolve(response);
        } catch {
          // 继续接收数据
        }
      };
      this.process.stdout?.on('data', handler);
      this.process.stderr?.on('data', (d) => reject(d.toString()));
    });
  }
}
```

### Golang 集成（gRPC）

适用于微服务架构：

```protobuf
// proto/kgm.proto
syntax = "proto3";
package kgm;

service Orchestrator {
  rpc Orchestrate(OrchestrateRequest) returns (OrchestrateResponse);
  rpc StreamOrchestrate(stream OrchestrateRequest) returns (stream OrchestrateResponse);
}

message OrchestrateRequest {
  string query = 1;
  map<string, string> context = 2;
  repeated string tools = 3;
}

message OrchestrateResponse {
  string answer = 1;
  repeated ToolCall tool_calls = 2;
  map<string, string> metadata = 3;
}

message ToolCall {
  string tool = 1;
  map<string, string> params = 2;
  string result = 3;
}
```

```typescript
// src/integrations/golangGrpc.ts
import * as grpc from '@grpc/grpc-js';
import * as protoLoader from '@grpc/proto-loader';

const PROTO_PATH = './proto/kgm.proto';
const packageDef = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const kgmProto = grpc.loadPackageDefinition(packageDef) as any;

export class GolangOrchestratorClient {
  private client: any;

  constructor(address: string = 'localhost:50051') {
    this.client = new kgmProto.kgm.Orchestrator(
      address,
      grpc.credentials.createInsecure()
    );
  }

  orchestrate(query: string, context: Record<string, string> = {}, tools: string[] = []) {
    return new Promise((resolve, reject) => {
      this.client.Orchestrate(
        { query, context, tools },
        (err: any, response: any) => {
          if (err) reject(err);
          else resolve(response);
        }
      );
    });
  }
}
```

### Python 集成（HTTP API / OpenAI 兼容）

KGM 原生支持 OpenAI 兼容接口，Python 应用可直接调用：

```python
# python_client.py
from openai import OpenAI

client = OpenAI(
    api_key="your-api-key",
    base_url="http://localhost:3000/v1"  # KGM 服务地址
)

# 方式 1：直接使用 OpenAI 兼容接口
response = client.chat.completions.create(
    model="auto",
    messages=[
        {"role": "system", "content": "你是一个助手"},
        {"role": "user", "content": "你好，请介绍一下自己"}
    ]
)
print(response.choices[0].message.content)

# 方式 2：使用 KGM 扩展接口
import requests

# 调用知识图谱检索
graph_response = requests.post(
    "http://localhost:3000/v1/kgm/graph/retrieve",
    headers={"Authorization": "Bearer your-api-key"},
    json={"query": "查找相关实体", "top_k": 5}
)
print(graph_response.json())
```

### Python Orchestrator 桥接（避免生态不匹配）

如果需要复用现有 Python Orchestrator 的调度逻辑，可通过以下方式桥接：

```python
# python_orchestrator_bridge.py
from flask import Flask, request, jsonify
from kgm_client import KGMRestClient

app = Flask(__name__)
kgm = KGMRestClient("http://localhost:3000")

@app.route("/orchestrate", methods=["POST"])
def orchestrate():
    """
    Python Orchestrator 桥接服务
    将 Python 侧的调度逻辑暴露为 HTTP API
    """
    data = request.json
    query = data.get("query")
    strategy = data.get("strategy", "auto")

    # 调用 KGM 的原生能力（知识图谱、记忆检索等）
    graph_result = kgm.graph.query(query)
    memory_result = kgm.memory.search(query)

    # Python 侧的业务调度逻辑
    orchestrated_result = your_orchestrator_logic(
        query=query,
        graph_data=graph_result,
        memory_data=memory_result,
        strategy=strategy
    )

    return jsonify(orchestrated_result)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
```

```typescript
// src/integrations/pythonBridge.ts
import { createLLMClient } from '../llm/client';

export class PythonOrchestratorBridge {
  private baseURL: string;
  private client: ReturnType<typeof createLLMClient>;

  constructor(baseURL: string = 'http://localhost:8000') {
    this.baseURL = baseURL;
    this.client = createLLMClient({
      provider: 'openai-compatible',
      baseURL: `${baseURL}/v1`,
      apiKey: 'dummy',
      model: 'orchestrator',
    });
  }

  async orchestrate(query: string, strategy = 'auto') {
    const response = await fetch(`${this.baseURL}/orchestrate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, strategy }),
    });
    return response.json();
  }
}
```

---

## 从源码开发本仓库

```bash
git clone <你的仓库> && cd <仓库目录>
npm install
npm run build
npm run dev:enhanced
```

---

## 版本说明 0.1.9

### 实现内容
| 模型系列 | 文件 | 支持型号 | 状态 |
|---------|------|---------|------|
| **Qwen 3.5/3.6** | [src/native/gpu/qwen3.ts](./Yueli-KGM-Computing/src/native/gpu/qwen3.ts:0:0-0:0) | 7B/14B/32B/72B | ✅ |
| **GLM 5.0/5.1** | [src/native/gpu/glm5.ts](./Yueli-KGM-Computing/src/native/gpu/glm5.ts:0:0-0:0) | 9B/32B | ✅ |
| **Google Gemma 4** | [src/native/gpu/gemma4.ts](./Yueli-KGM-Computing/src/native/gpu/gemma4.ts:0:0-0:0) | 2B/4B/9B/27B | ✅ |
| **MiniMax 2.5/2.7** | [src/native/gpu/minimax25.ts](./Yueli-KGM-Computing/src/native/gpu/minimax25.ts:0:0-0:0) | 4B/8B/32B/456B | ✅ |
| **MiMo 2.5** | [src/native/gpu/mimo25.ts](./Yueli-KGM-Computing/src/native/gpu/mimo25.ts:0:0-0:0) | 1.5B/7B/13B/30B | ✅ |
| **vMLX (Apple Silicon)** | [src/native/gpu/vmlxAdapter.ts](./Yueli-KGM-Computing/src/native/gpu/vmlxAdapter.ts:0:0-0:0) | M1/M2/M3/M4 | ✅ |

### 运行测试
```bash
npm run test:native-gpu-models
```

**结果**: 63 测试通过，0 失败

### 主要功能
- **权重别名映射**: 支持 Hugging Face 格式 → 本地 GPU 格式
- **内存估算**: 支持多种量化格式 (Q4_0, Q8_0, F16 等)
- **统一接口**: [getModelConfig()](./Yueli-KGM-Computing/src/native/gpu/index.ts:151:0-195:1), [estimateModelMemory()](./Yueli-KGM-Computing/src/native/gpu/index.ts:197:0-270:1)
- **模型注册表**: `MODEL_REGISTRY` 包含所有支持模型
- **特色功能**:
  - Qwen: 滑动窗口、Yarn RoPE
  - GLM: Prefix Attention、MQA/GQA
  - Gemma: GeGLU、嵌入归一化
  - MiniMax: 400K 上下文、KV 压缩
  - MiMo: 端侧量化、推荐 batch size
  - vMLX (Apple MLX): 统一内存、Metal 加速、前缀缓存、连续批处理
